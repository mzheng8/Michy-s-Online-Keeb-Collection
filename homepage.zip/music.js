const playmusicbutton = document.querySelector('.musicbutton');
let summerlight = document.querySelector('#audio');
playmusicbutton.addEventListener('click',()=>{
    summerlight.play();
});